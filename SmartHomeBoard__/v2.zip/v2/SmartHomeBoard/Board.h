#pragma once
class Board
{
public:
	static void Reset(unsigned long timeout);

};
