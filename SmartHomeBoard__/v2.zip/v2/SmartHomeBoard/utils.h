// utils.h
#pragma once

extern int memoryFree();
